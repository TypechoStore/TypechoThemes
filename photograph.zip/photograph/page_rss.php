<?php
/**
 * RSS订阅
 * @package custom
 */
?>
<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
header("Content-type: text/xml");
header('HTTP/1.1 200 OK');
$feed = new Typecho_Feed("1.0","RSS 2.0","UTF-8","zh-CN");
$feed->setTitle($this->options->title);
$feed->setBaseUrl($this->options->siteUrl);
$feed->setFeedUrl($this->options->siteUrl);
$feed->setSubTitle($this->options->description);
$this->widget('Widget_Contents_Post_Recent','pageSize=10')->to($result);
while($result->next()){
	$feed->addItem(array(
		'title'     =>  $result->title,
		'content'   =>  $this->options->feedFullText ? $result->content : (false !== strpos($result->text, '<!--more-->') ?
		$result->excerpt . "<p class=\"more\"><a href=\"{$result->permalink}\" title=\"{$result->title}\">[...]</a></p>" : $result->content),
		'date'      =>  $result->created,
		'link'      =>  $result->permalink,
		'author'    =>  $result->author,
		'excerpt'   =>  $result->description,
		'comments'  =>  $result->commentsNum
	));
}
echo $feed->__toString();
?>
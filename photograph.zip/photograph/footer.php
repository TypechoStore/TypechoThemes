<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<div id="side-button">
	<ul>
		<li id="go-top"><span class="glyphicon glyphicon-arrow-up" aria-hidden="true"></span></li>
		<li id="go-bottom"><span class="glyphicon glyphicon-arrow-down" aria-hidden="true"></span></li>
		<!--侧滑评论所需开始-->
		<?php if ($this->is('post')) : ?>
		<li id="ex-comment"><span class="glyphicon glyphicon-comment" aria-hidden="true"></span></li>
		<?php endif; ?>
		<!--侧滑评论所需结束-->
		<?php
		if($this->options->isRandomAlbum=="y"){
		$queryRandom= "select cid from ".$this->db->getPrefix()."contents where type='post' AND status='publish' ORDER BY rand()";
		$rowRandom = $this->db->fetchRow($queryRandom);
		?>
		<li onclick="location.href='<?=$this->options->siteUrl();?>index.php/<?=$rowRandom["cid"];?>.html';"><span class="glyphicon glyphicon-random" aria-hidden="true"></span></li>
		<?php
		}
		?>
	</ul>
</div>

<footer class="footer">
	<?php if ($this->options->notice): ?>
	<p class="related">公告：<?php $this->options->notice() ?></p>
	<?php endif; ?>
	<p class="related">
		<?=printFriends($this->options->friendlink);?>
	</p>
	<p class="related">
		本站共<?=getDataCount("attachnum")["attachnum"];?>张图片在<?=getDataCount("albumnum")["albumnum"];?>个相册中，他们被分成<?=getDataCount("catenum")["catenum"];?>个类别，并有<?=getDataCount("pagenum")["pagenum"];?>个页面和<?=getDataCount("commentnum")["commentnum"];?>条评论
	</p>
	<p class="related">
		<a href="<?=$this->options->siteUrl();?>"><?php $this->options->title();?></a> &copy; <?php echo date('Y'); ?> Powered By <a href="http://typecho.org/" target="_blank">Typecho</a> / Theme By <a href="https://siitake.cn/" target="_blank">Siitake</a> / Modify By Diamond0419
	</p>
	<?php if ($this->options->icp): ?>
	<p class="related"><a href="http://www.miitbeian.gov.cn/" target="_blank"><?php $this->options->icp() ?></a></p>
	<?php endif; ?>
	<?php if ($this->options->statistics): echo '<div style="display:none;">'; $this->options->statistics(); echo '</div>'; endif; ?>
</footer><!-- end #footer -->
<script type="text/javascript" src="https://cdn.bootcss.com/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php $this->options->themeUrl('js/masonry-docs.min.js'); ?>"></script>
<script type="text/javascript" src="<?php $this->options->themeUrl('lightgallery/js/lightgallery.min.js'); ?>"></script>
<script type="text/javascript" src="<?php $this->options->themeUrl('lightgallery/js/lg-pager.min.js'); ?>"></script>
<script type="text/javascript" src="<?php $this->options->themeUrl('lightgallery/js/lg-autoplay.min.js'); ?>"></script>
<script type="text/javascript" src="<?php $this->options->themeUrl('lightgallery/js/lg-fullscreen.min.js'); ?>"></script>
<script type="text/javascript" src="<?php $this->options->themeUrl('lightgallery/js/lg-zoom.min.js'); ?>"></script>
<script type="text/javascript" src="<?php $this->options->themeUrl('lightgallery/js/lg-thumbnail.min.js'); ?>"></script>
<script type="text/javascript">if(history.length < 2){$('.header-post-back').css('opacity', 0);}</script>
<?php if($this->options->isLazy=='y'){?>
<script type="text/javascript" src="https://apps.bdimg.com/libs/jquery-lazyload/1.9.5/jquery.lazyload.min.js"></script>
<script type="text/javascript">
	/*lazyload*/
	<?php if ($this->is('post')){?>
	$(function() {
		$("img.lazy").lazyload({
			placeholder : "<?php echo $this->options->lazyUrl!=null?$this->options->lazyUrl:"https://ws3.sinaimg.cn/large/005V7SQ5ly1fylk8tcxu9g30m80godh4.jpg";?>",
			effect: "fadeIn",
			load: function(ele){
				/*masonry*/
				var $container = $('#masonry');
				$container.imagesLoaded(function() {
					$container.masonry({
						itemSelector: '.post-item',
						gutter: 0,
						isAnimated: false,
					});
				});
            },
		});
	});
	<?php }else{?>
	$(function() {
		$("img.lazy").lazyload({
			placeholder : "<?php echo $this->options->lazyUrl!=null?$this->options->lazyUrl:"https://ws3.sinaimg.cn/large/005V7SQ5ly1fylk8tcxu9g30m80godh4.jpg";?>",
			effect: "fadeIn",
		});
	});
	<?php }?>
</script>
<?php }?>
<script type="text/javascript">
	/*侧滑评论所需开始*/
	$(function() {
		if(window.location.href.indexOf("#comment-")>-1) {
			$("#post-comments").addClass("comment-open");
		}
		$("#ex-comment").click(function() {
			$("#post-comments").toggleClass("comment-open");
		});
	});
	/*侧滑评论所需结束*/
	/*goToTop*/
	$(function(){
		$("#go-top").hide();
		$(window).scroll(function(){
			if($(this).scrollTop() > 100){
				$('#go-top').fadeIn();
			}else{
				$('#go-top').fadeOut();
			}
		});
		$('#go-top').click(function(){
			$('html ,body').animate({scrollTop: 0}, 300);
			return false;
		});
	});
	/*goToBottom*/
	$(function(){
		$(window).scroll(function(){
			if($(this).scrollTop() > (document.body.scrollHeight - 1000)) {
				$('#go-bottom').fadeOut();
			}else{
				$('#go-bottom').fadeIn();
			}
		});
		$('#go-bottom').click(function(){
			$('html ,body').animate({scrollTop: document.body.scrollHeight}, 300);
			return false;
		});
	});
</script>
<script type="text/javascript">
<?php if ($this->is('post')) : ?>
	$(function() {
		/*瀑布流*/
		var $container = $('#masonry');
		$container.imagesLoaded(function() {
			$container.masonry({
				itemSelector: '.post-item',
				gutter: 0,
				isAnimated: false,
			});
		});
		/*灯箱*/
		var lg = document.getElementById('masonry');
		lightGallery(lg, {
			selector: '.post-item',
			download: false,
			enableTouch: true
		});
  });
<?php endif; ?>
</script>
<?php $this->footer(); ?>
</body>
</html>

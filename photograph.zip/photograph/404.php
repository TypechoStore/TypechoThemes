<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!--
<?php //$this->need('header.php'); ?>
<div class="col-mb-12 col-tb-8 col-tb-offset-2">
	<div class="error-page">
		<h2 class="post-title">404 - <?php _e('页面没找到'); ?></h2>
		<p><?php _e('你想查看的页面已被转移或删除了, 要不要搜索看看: '); ?></p>
		<form method="post">
			<p><input type="text" name="s" class="text" autofocus /></p>
			<p><button type="submit" class="submit"><?php _e('搜索'); ?></button></p>
		</form>
	</div>
</div>
<?php //$this->need('footer.php'); ?>
-->
<!doctype html>
<html>
<head>
<meta charset="<?php $this->options->charset(); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0">
<meta name="renderer" content="webkit">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link rel="icon" href="<?php $this->options->themeUrl('favicon.png'); ?>">
<link rel="apple-touch-icon" href="<?php $this->options->themeUrl('favicon.png'); ?>">
<title>404</title>
<style>
	body{
		background-color:#444;
		font-size:14px;
	}
	h3{
		font-size:60px;
		color:#eee;
		text-align:center;
		padding-top:30px;
		font-weight:normal;
	}
</style>
</head>
<body>
<h3>
	404 - <?php _e('您请求的页面不存在!'); ?>
	<form method="post">
		<p><input type="text" name="s" size="40" placeholder="你想查看的页面已被转移或删除了,要不要搜索看看" class="text" autofocus /><button type="submit"><?php _e('搜索'); ?></button><button onClick="location.href='<?=$this->options->siteUrl();?>';" type="button"><?php _e('首页'); ?></button></p>
	</form>
</h3>
</body>
</html>
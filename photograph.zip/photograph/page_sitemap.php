<?php
/**
 * Sitemap地图
 * @package custom
 */
?>
<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
header("Content-type: text/xml");
header('HTTP/1.1 200 OK');
echo '<?xml version="1.0" encoding="UTF-8"?>';
echo '<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">';
$this->widget('Widget_Contents_Post_Recent','pageSize=10')->to($result);
while($result->next()){
	?>
	<url>
		<loc><?php echo $result->permalink; ?></loc>
		<lastmod><?php echo $result->created; ?></lastmod>
		<changefreq>monthly</changefreq>
		<priority>0.6</priority>
	</url>
	<?php
}
?>
</urlset>
<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>


	<script src="<?php $this->options->themeUrl('assets/js/001.js'); ?>"></script>
	<script src="<?php $this->options->themeUrl('assets/js/002.js'); ?>"></script>
	<div class="footer">
		<p>Typecho因你而荣耀 | Theme by <a href="https://www.vpsmm.com/" target="_blank">win95</a></p>
		<!--尊重作者，保留版权信息，如果强烈需要去掉，希望能捐赠作者一杯咖啡，捐赠地址：https://www.vpsmm.com/pay.shtml 谢谢-->
	</div>


<?php $this->footer(); ?>
</body>
</html>

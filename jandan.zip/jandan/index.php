<?php
/**
 * 这是 Typecho 仿煎蛋的皮肤
 * 
 * @package jandan Theme
 * @author Crll
 * @version 0.1
 * @link http://eoo.hk
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 ?>
   <h3 class="place">当前位置：<a href="<?php $this->options->siteUrl(); ?>">首页</a></h3>

 
	<?php while($this->next()): ?>

<dl class="post">
    <dd class="shu"><?php $this->commentsNum('0', '1', '%d'); ?></dd>
    <dd class="zi">
 
<?php
preg_match_all("/\<img.*?src\=(\'|\")(.*?)(\'|\")[^>]*>/i", $this->content, $matches);
$imgCount = count($matches[0]);
if($imgCount >= 1){
    $img = $matches[2][0];
echo <<<Html

 <a href="{$this->permalink}" title="{$this->title}" class="tu"><img src="{$img}?x-oss-process=style/szd2"  alt="{$this->title}" /></a>
     
Html;
}
?> 
 
 
        <h2><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h2>
        <em><?php $this->author(); ?>发表于<?php $this->date(); ?> | <?php $this->category(','); ?> |  <?php $this->views(); ?>个浏览</em>
        <?php $this->content(''); ?>
    </dd>
    <div class="clear"></div>
</dl>
 
	<?php endwhile; ?>
   <dl class="pagebar">   	 <?php $this->pageNav('&laquo; 前一页', '后一页 &raquo;'); ?>
  </dl>
   </div> <!-- end #main-->
 
<?php $this->need('sidebar.php'); ?>
<?php $this->need('footer.php'); ?>

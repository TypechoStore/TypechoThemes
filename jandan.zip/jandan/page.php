<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

 <h3 class="place">当前位置：<a href="<?php $this->options->siteUrl(); ?>">首页</a> / <?php $this->title() ?> 页面</h3>
    <dl id="info">
 <dd id="title">
             
            <h1><?php $this->title() ?></h1>
            
        </dd>

        <dd id="neir">
 
            <?php $this->content(); ?>
        </dd>

        
    </dl>

   

  
</div><!-- end #main-->

<?php $this->need('sidebar.php'); ?>
<?php $this->need('footer.php'); ?>

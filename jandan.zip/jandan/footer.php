<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
 </div>
 <!-- end #body -->
<div id="foot">
    &copy; <?php echo date('Y'); ?> <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a> <br>
   ♥ Do have faith in what you're doing.
</div>
</div>
<div id="up">↑</div>
<script src="<?php $this->options->themeUrl('js/top.js'); ?>" type="text/javascript"></script>


 
<?php $this->footer(); ?>
</body>
</html>

<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE HTML>
<html class="no-js">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title><?php $this->archiveTitle(array(
            'category'  =>  _t('分类 %s 下的文章'),
            'search'    =>  _t('包含关键字 %s 的文章'),
            'tag'       =>  _t('标签 %s 下的文章'),
            'author'    =>  _t('%s 专栏')
        ), '', ' - '); ?><?php $this->options->title(); ?></title>

    <!-- 使用url函数转换相关路径 -->
<script src="<?php $this->options->themeUrl('js/jquery-2.2.4.min.js'); ?>" type="text/javascript"></script>

<link rel="stylesheet" type="text/css" href="<?php $this->options->themeUrl('style.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php $this->options->themeUrl('grid.css'); ?>">
   <!-- 通过自有函数输出HTML头部信息 -->
<meta name="description" content="水煮蛋是一个简单、温暖的小站" />
<meta name="keywords" content="szd2,szd2.com,水煮蛋,新鲜事," /> 
</head>
<body>
 
     <div id="w960">
            <div id="head">
                <h2><a href="<?php $this->options->siteUrl(); ?>" title="<?php $this->options->title() ?>"><img src="<?php $this->options->themeUrl('img/logo.png'); ?>" alt="<?php $this->options->title() ?>"></a></h2>
                <span class="ad"><table width="640" height="60" border="0" cellpadding="0" cellspacing="0" bgcolor="#f9f9f9">
  <tr align="center">
    <td>640*60广告位</td>
  </tr>
</table></span>                <div class="clear"></div>
            </div>

            <div id="nav">
                <ul>
                    <li id="nvabar-item-index"><a href="<?php $this->options->siteUrl(); ?>">首页</a></li>

<?php  $this->widget('Widget_Metas_Category_List')->parse('<li class="li-cate"><a href="{permalink}">{name}</a></li>');  ?> 

      <?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
                    <?php while($pages->next()): ?>
                    <li class="li-cate"><a<?php if($this->is('page', $pages->slug)): ?> class="current"<?php endif; ?> href="<?php $pages->permalink(); ?>" title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a></li>
                    <?php endwhile; ?>
                  
                  <div class="clear"></div>
                </ul>   <!-- end #header -->
          </div>
       
       <div id="contenr">
    <div id="left">
      
   

    
    

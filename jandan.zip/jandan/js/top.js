$("#nav li").hover(function() {
    if($(this).find("li").length > 0){
        $(this).children("ul").stop(true, true).slideDown(300);
        $(this).addClass("hover");
    }
},function() {
    $(this).children("ul").stop(true, true).slideUp("fast");
    $(this).removeClass("hover");
});

$(function(){
    var surl = location.href;
    var surl2 = $(".place a:eq(1)").attr("href");
    $("#nav ul li a").each(function() {
        if ($(this).attr("href")==surl || $(this).attr("href")==surl2) $(this).parent().addClass("on");
    });
});

//回到顶部
$(function(){
    var fixedh = $(document);
    $(window).scroll(function(){
        if(fixedh.scrollTop()>=400){
            $('#up').show();
        }else{
            $('#up').hide();
        }
    }) 
    $("#up").click(function(){
        $('body,html').animate({scrollTop:0},300);
    })
});
 
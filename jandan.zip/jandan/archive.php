<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

 <h3 class="place">当前位置：<a href="<?php $this->options->siteUrl(); ?>">首页</a> / <?php $this->archiveTitle(array(
            'category'  =>  _t('分类 %s 下的文章'),
            'search'    =>  _t('包含关键字 %s 的文章'),
            'tag'       =>  _t('标签 %s 下的文章'),
            'author'    =>  _t('%s  专栏')
        ), '', ''); ?>


<?php if ($this->is('author')) : ?>
<br><br>
<div class="post f">
  <img src="//www.gravatar.com/avatar/e62fe69b0f2f6c17be836f0af7711ef7?s=80&d=//pic.yupoo.com/jdvip/271258f17cef/small.gif&r=G" title="563" style="float:right;" width="80" height="80"/>  
<strong>Website:</strong> <a href="http://eoo.hk">http://eoo.hk</a><br>
<strong>Column:</strong> <a href="http://szd2.com/author/crll">http://szd2.com/author/1</a><br>
<strong>Posted:</strong> 20 posts<br>
<strong>Registered:</strong> 2015-05-05 15:00:03</div>
<?php endif; ?>

</h3>
 
   
        <?php if ($this->have()): ?>
    	<?php while($this->next()): ?>
       
<dl class="post">
    <dd class="shu"><?php $this->commentsNum('0', '1', '%d'); ?></dd>
    <dd class="zi">
       <?php
preg_match_all("/\<img.*?src\=(\'|\")(.*?)(\'|\")[^>]*>/i", $this->content, $matches);
$imgCount = count($matches[0]);
if($imgCount >= 1){
    $img = $matches[2][0];
echo <<<Html

 <a href="{$this->permalink}" title="{$this->title}" class="tu"><img src="{$img}?x-oss-process=style/szd2"  alt="{$this->title}" /></a>
     
Html;
}
?> 
        <h2><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h2>
        <em><?php $this->category(','); ?> | <?php $this->date(); ?> | <?php $this->views(); ?>个浏览</em>
        <?php $this->content(''); ?>
    </dd>
    <div class="clear"></div>
</dl>
    	<?php endwhile; ?>
        <?php else: ?>
           <dl class="post">
                <h2 class="post-title"><?php _e('没有找到内容'); ?></h2>
         </dl>
        <?php endif; ?>

   <dl class="pagebar">   	 <?php $this->pageNav('&laquo; 前一页', '后一页 &raquo;'); ?>
  </dl>
   </div> <!-- end #main--><!-- end #main -->

	<?php $this->need('sidebar.php'); ?>
	<?php $this->need('footer.php'); ?>

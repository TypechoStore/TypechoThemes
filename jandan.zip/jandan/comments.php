<?php function threadedComments($comments, $options) {
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';  
        } else {
            $commentClass .= ' comment-by-user';  
        }
    }
 
    $commentLevelClass = $comments->levels > 0 ? ' comment-child' : ' comment-parent';  
?>
<ul class="msg" id="cmt<?php $comments->theId(); ?>"> 
 <li class="msgname">

 <?php $comments->gravatar('46', ''); ?>
 <p class="commentname"><a href="<?php $comments->url(); ?>" rel="nofollow" target="_blank"><?php $comments->author(); ?></a>&nbsp;&nbsp;<small>评论于 [<?php $comments->date('Y-m-d H:i:s'); ?>]&nbsp;&nbsp;<span class="revertcomment"><?php $comments->reply(); ?></span></small></p>
	    <p class="commentinfo"><?php $comments->content(); ?><label id="AjaxComment<?php $comments->theId(); ?>"></label></p>

  
<?php if ($comments->children) { ?>  
    <div class="comment-children">
        <?php $comments->threadedComments($options); ?>  
    </div>
<?php } ?>
</li></ul> 
<?php } ?>















<div id="comments">	
                
<div class="tx-comments">
        <h3><?php $this->commentsNum(_t('暂无评论'), _t('仅有一条评论'), _t('已有 %d 条评论')); ?>：</h3>
    <div class="pd15">
    <?php $this->comments()->to($comments); ?>
    <?php if ($comments->have()): ?>
	 
     <?php $comments->listComments(); ?>

    <?php $comments->pageNav('&laquo; 前一页', '后一页 &raquo;'); ?>
    
    <?php endif; ?>
 
  </div>
    </div>
<!--评论框-->
    <?php if($this->allow('comment')): ?>
 <div class="tx-comment" id="divCommentPost">
  <?php if($this->user->hasLogin()): ?>
    <h3> <small  style="float:right;">  <?php $comments->cancelReply(); ?></small>  欢迎 <span class="tx-red"><a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>. <a href="<?php $this->options->logoutUrl(); ?>" title="Logout"><?php _e('退出'); ?> &raquo;</a></span> 发表评论:</h3>
   <?php else: ?>
  <h3> <small style="float:right;">  <?php $comments->cancelReply(); ?></small>  发表评论:</h3>
 <?php endif; ?>

  <div class="pd15">
   <form method="post" action="<?php $this->commentUrl() ?>" id="comment-form" role="form" class="clearfix"> 	    	
 
            <?php if(!$this->user->hasLogin()): ?>
    		 
<div class="tx-comment-box tx-comment-ul3"><input type="text" name="author" id="author"  class="text" size="28" tabindex="1" placeholder="名称(*)" value="<?php $this->remember('author'); ?>" required /></div>
    		 
<div class="tx-comment-box tx-comment-ul3 tx-comment-ul3-2"><input type="email" name="mail" id="mail" size="28" tabindex="2" placeholder="邮箱" class="text" value="<?php $this->remember('mail'); ?>"<?php if ($this->options->commentsRequireMail): ?> required<?php endif; ?> /></div>
    		 
   
    		 
            <?php endif; ?>
    	 <div class="tx-comment-box tx-comment-textarea">
                <textarea rows="8" cols="50" name="text" id="textarea" class="text" cols="50" rows="4" tabindex="5"  required ><?php $this->remember('text'); ?></textarea>
           
                <button type="submit" tabindex="6" value="提交" class="button"><?php _e('提交评论'); ?></button>
             </div>
    	</form>
    </div>
    <?php else: ?>
    <h3><?php _e('评论已关闭'); ?></h3>
    <?php endif; ?>
</div>
  </div>
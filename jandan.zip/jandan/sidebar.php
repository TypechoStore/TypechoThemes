<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
  <div id="rigth">
        <dl class="ss"> 
            <form name="search" method="post" action="<?php $this->options->siteUrl(); ?>">
              <input type="text" name="s" size="11" id="edtSearch" /> 
              <input type="submit" value="搜索"  class="search-submit" id="btnPost"/>
          </form>
        </dl>
                <dl class="function" id="divPrevious">
<dt class="function_t">最近发表</dt><dd class="function_c">

<ul>
 <?php $this->widget('Widget_Contents_Post_Recent')
            ->parse('<li><a href="{permalink}">{title}</a></li>'); ?>
</ul>
</dd>
</dl>
    

                <dl class="function" id="divPrevious">
<dt class="function_t">标签</dt><dd class="function_c">

<?php $this->widget('Widget_Metas_Tag_Cloud', 'sort=mid&ignoreZeroCount=1&desc=0&limit=30')->to($tags); ?>
<?php if($tags->have()): ?>
<ul class="tags-list">
<?php while ($tags->next()): ?>
    <li><a href="<?php $tags->permalink(); ?>" rel="tag" class="size-<?php $tags->split(5, 10, 20, 30); ?>" title="<?php $tags->count(); ?> 个话题"><?php $tags->name(); ?></a></li>
<?php endwhile; ?>
<?php else: ?>
    <li><?php _e('没有任何标签'); ?></li>
<?php endif; ?>
</ul>
</dd>
</dl>





<dl class="function" id="divtxcomments">
<dt class="function_t">最新评论</dt><dd class="function_c">


<ul>    
  <?php $this->widget('Widget_Comments_Recent')->to($comments); ?>
        <?php while($comments->next()): ?>
      <li><span class="tx-avatar"><a href="<?php $comments->permalink(); ?>"><?php $comments->gravatar('32', 'http://szd2.com/system/themes/szd2/img/0.png'); ?></a></span><p><a href="<?php $comments->permalink(); ?>"><?php $comments->excerpt(20, '...'); ?></a></p>
        <small><?php $comments->author(false); ?> 评论于：<?php $comments->date('m月j日'); ?></small>
        </li>
        <?php endwhile; ?> 
</ul>

</dd>
</dl>      <div class="clear"></div>
         
        </div>
    <div class="clear"></div>
 
 <!-- end #sidebar -->

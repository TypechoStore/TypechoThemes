<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

 <h3 class="place">当前位置：<a href="<?php $this->options->siteUrl(); ?>">首页</a> / <?php $this->title() ?> 正文</h3>
    <dl id="info">
 <dd id="title">
            <span><?php $this->commentsNum('0', '1', '%d'); ?></span>
            <h1><?php $this->title() ?></h1>
            <em><?php $this->category(','); ?> | <?php $this->author(); ?>发表于<?php $this->date(); ?> | <?php $this->views(); ?>个浏览</em>
        </dd>

        <dd id="neir">
 
            <?php $this->content(); ?>
        </dd>

        <dd class="cnxh">
            <h2>猜你喜欢</h2>
            <ul>
                            </ul>
        </dd>
    </dl>

     <?php $this->need('comments.php'); ?>
 

  
</div><!-- end #main-->

<?php $this->need('sidebar.php'); ?>
<?php $this->need('footer.php'); ?>

<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>


<h3 class="place">当前位置：<a href="#">首页</a> / 404</h3>
    <dl id="info">
  

        <dd id="neir">
 404 - <?php _e('页面没找到'); ?>
             
        </dd>

        
    </dl>

   

  
</div><!-- end #main-->

 
	<?php $this->need('footer.php'); ?>

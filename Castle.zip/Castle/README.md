# Castle-Typecho-Theme
一个基于MDUI编写的MD风格的Typecho主题

## Version
1.1.5

升级前请备份主题设置，并重新应用本主题！

## 相关链接
Demo站点：https://ohmyga.net (目前demo站用的是Castle-RV的bug版)

主题介绍：主题介绍站死亡中(博客重装了)

更新日志：更新日志死亡中(理由如上)

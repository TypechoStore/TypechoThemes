# Typecho-theme-DUX

>Forked from https://coding.net/u/Arco-X/p/DUX-for-Typecho/git

一款基于大前端DUX for Wordpress主题修改而来的主题。

# 特性
- 修复了原版不能正常评论的问题
- 美化了样式，修改细节
- 增加了一些小功能

# 预览地址
http://blog.hicasper.com

![Typecho-theme-DUX.png](https://i.loli.net/2018/09/22/5ba5d0e56f3c9.png)

>本主题仅基于爱好修改，使用时请尊重原作者大前端版权。
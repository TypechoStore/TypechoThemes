inker for typecho 映客主题模板
---
# 模板截图

- 电脑版 综合截图
<img src="https://ws3.sinaimg.cn/large/005V7SQ5ly1g0jtbpoz7hj30q40g7qb4.jpg" width="100%">
- 电脑版 文章截图
<img src="https://ws3.sinaimg.cn/large/005V7SQ5ly1g0ju5vwozwj30u00w4qhs.jpg" width="100%">
- 手机版 首页截图
<img src="https://ws3.sinaimg.cn/large/005V7SQ5ly1g0jtwhnkivj30tz0k015j.jpg" width="100%">

# 模板介绍

A InkerForTypecho Template From tongleer.com

这是一个来自同乐儿的Typecho版本的映客主题模板。

为防止不改版本号更新主题，可关注微信公众号，和作者取得联系。

<img src="http://me.tongleer.com/content/uploadfile/201706/008b1497454448.png">

# 增加功能

如果有增加功能的需求，在这里

https://weidian.com/?userid=2055073

购买零食后在以上微信公众号留言，和作者取得联系。

# 模板特点
 - 支持pjax、前台登陆、手机登陆、邮箱登陆、QQ登陆、微博登陆、图片验证码、短信验证码，并后台可控制开启状态。

 - 支持打赏二维码设置
 
 - 支持清理无用自定义字段使数据库表更清爽
 
 - 支持手机版网页
 
 - 支持WeMedia付费阅读插件和CateFilter插件配合使用
 
 - 支持检查更新
 
 - 支持修改自定义logo、favicon、自定义二维码、服务条款、隐私条款
 
 - 支持添加友情链接无需插件、底部自定义信息、备案号、统计代码
 
 - 支持畅言评论
 
 - 支持添加页面广告代码，助力获益。

# 关于使用
 - 将本主题里的所有文件放在您网站目录的usr/themes内，注意文件夹名字必须为inker。

 - 后台->外观->启用本主题->进入设置外观内配置信息
 
 - 因为主题使用前台登陆，所以可以自由将后台登陆注册页面编写禁止登陆或者禁止注册的判断。

 - 本主题限个人使用，公开发布请注明原作者：二呆，及链接：http://www.tongleer.com

 - 如果你喜欢这个主题，别忘记给我打赏哦：http://api.tongleer.com/web/pay.php
 
 - 如果遇到bug或者使用问题，欢迎给我来email：diamond@tongleer.com
 
 - 1元入群：http://joke.tongleer.com/373.html

# 官方演示

http://joke.tongleer.com

# 制作缘由
 - 本作者作为映客迷而开发的第二款仿映客网页的Typecho主题模板。

# 版本记录
2019-10-02 V1.0.5

	修复因加载cloudflare的layer.js失效导致的bug。
	
2019-03-22

	V1.0.2	修复了因cdn.bootcss.com中JS静态资源不可访问导致的js失效的问题。
	
2019-02-26 V1.0.1：

	第一个版本降世
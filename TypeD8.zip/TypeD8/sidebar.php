<aside class="sidebar">	
	<div class="widget widget_recent_entries">
		<h3 class="widget_tit">热门推荐</h3>
		<ul><?php TePostViews_Plugin::outputHotPosts() ?></ul>
	</div>
	
	<!--幻灯片开始--> 
	<?php if ($this->options->Slider == 'SliderTrue'): ?>
	<div class="widget d_slidebanner">		
		<?php slout(); ?>
	</div>
	<?php endif; ?>
	<!--幻灯片结束-->
	
	<!--推荐广告位--> 
	<?php if ($this->options->tuijian == 'tuijianTrue'): ?>
	<?php $sad1=sitebar_ad($this->options->sidebarAD); 
	$maxi=floor(count($sad1)/3);
	for($i=1;$i<=$maxi;$i++){
		$icss=($i%2)+1;
		$tmp='<div class="widget d_textbanner"><a class="style0'.$icss.'" href="'.$sad1[$i*3-3].'" target="_blank"><strong>推荐广告</strong><h2>'.$sad1[$i*3-2].'</h2><p>'.$sad1[$i*3-1].'.</p></a></div>';
		echo $tmp;
	} ?>
	<?php endif; ?>
	<!--推荐广告位-->
	
	<div class="widget widget_recent_entries">
		<h3 class="widget_tit">随机文章</h3>
		<ul class="random"><?php getRandomPosts('10');?></ul>
	</div>
	
	<div class="widget d_tag">
		<h3 class="widget_tit">标签云</h3>
		<div class="d_tags">
		<?php $this->widget('Widget_Metas_Tag_Cloud', 'sort=mid&ignoreZeroCount=1&desc=0&limit=100')->to($tags); ?>
		<?php if($tags->have()): ?>
			<?php while ($tags->next()): ?>
				<a rel="tag" href="<?php $tags->permalink(); ?>"><?php $tags->name(); ?></a>
			<?php endwhile; ?>
		<?php else: ?>
			<a href="<?php $this->options->siteUrl(); ?>"><?php _e('没有任何标签'); ?></a>
		<?php endif; ?>
		</div>
	</div>
		
	<div class="widget widget_recent_entries">
		<h3 class="widget_tit">站点统计</h3>
		<ul><?php Typecho_Widget::widget('Widget_Stat')->to($stat); ?>
		<li>文章总数：<?php $stat->publishedPostsNum() ?>篇</li>
		<li>分类总数：<?php $stat->categoriesNum() ?>个</li>
		<li>评论总数：<?php $stat->publishedCommentsNum() ?>条</li>
		<li>运行时长：<?php getBuildTime(); ?></li>
		</ul>
	</div>
	
	<div class="widget widget_links">
		<h3 class="widget_tit">友情链接</h3>
		<ul class="xoxo blogroll">
			<li><a href="https://www.nihaowua.com"><b style="color:#f00;">你好污啊</b></a></li>
			<li><a href="https://www.typecho.wiki">TypechoWIKI</a></li>
			<li><a href="https://www.goubugou.net">购不够</a></li>
			<li><a href="https://www.1024lua.com">韩粉乐园</a></li>
			<li><a href="https://www.moidea.info/daohang.html">博客之家</a></li>		
		</ul>
	</div>
</aside>

</section>

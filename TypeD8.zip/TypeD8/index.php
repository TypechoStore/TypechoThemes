<?php
/**
 * 
 * TypeD8主题是移植自大前端的WORDPRESS早期版本的D8主题，界面基本上和WORDPRESS版本一致，功能可能稍微有出入，该主题是响应式布局，支持电脑、平板和手机的完美展示。
 *
 * @package TypeD8
 * @author Roogle
 * @version 1.0
 * @link https://www.moidea.info/
 */
 ?>

<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<section class="container">
	<div class="content-wrap">
		<div class="content">
			<div class="sticky">
				<h2 class="title">HOT</h2>
				<ul>
					<?php hotpost(); ?>
				</ul>
			</div>
			
			<section class="container">
				<h2 class="title"> The Lastest</h2>
				<?php while($this->next()): ?>
				<article class="excerpt excerpt-titletype">
					<div class="focus">
						<a href="<?php $this->permalink() ?>" class="thumbnail">
						<?php if ($this->options->RandomPicChoice !=='0' && array_key_exists('thumb',unserialize($this->___fields()))): ?>
	    <img src="<?php echo $this->fields->thumb; ?>"/>
	    <?php else: ?>
          <?php $thumb = showThumbnail($this); if(!empty($thumb)): ?>
	 <img src="<?php echo $thumb ?>"/>
	   <?php endif; ?>
        <?php endif; ?>
</a></div>
		
					<header><a class="cat"><?php $this->category(',',false); ?><i></i></a><h2><a href="<?php $this->permalink() ?>" title="<?php $this->title() ?>"><?php $this->title() ?></a></h2></header>
					<p><span class="muted muted_author"><i class="icon-user icon12"></i> <?php $this->author(); ?></span>
				<time class="muted" datetime="<?php $this->date('c'); ?>" title="<?php $this->date('y/m/d'); ?>"><i class="ico icon-time icon12"></i> <?php $this->date('Y/m/d'); ?></time>
				<span class="muted"><i class="icon-eye-open icon12"></i> <?php get_post_view($this) ?></span>
				<span class="muted"><i class="icon-comment icon12"></i> <a href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum(); ?></a></span></p>
					
					<p class="note"><?php $this->excerpt(220, '...'); ?>  </p>
				</article>
			<?php endwhile; ?>

			<div class="pagination">
				<ul><li class="prev-page"></li><a href='<?php $this->options->siteUrl(); ?>'>Home</a> <?php $this->pageLink('<x aria-label="Previous" class="newer-posts"><i class="fa fa-angle-left"></i></x>'); ?><span class="page-number"><?php if($this->_currentPage>1) echo $this->_currentPage;  else echo 1;?> Page / Total <?php echo ceil($this->getTotal() / $this->parameter->pageSize); ?> Page</span><?php $this->pageLink('<x aria-label="Next" class="older-posts">下一页<i class="fa fa-angle-right"></i></x>','next'); ?></ul>
			</div>
		</div>
	</div>
<?php $this->need('sidebar.php'); ?>

<?php $this->need('footer.php'); ?>
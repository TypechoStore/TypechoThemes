<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE HTML>
<html>
<head>
	<meta charset="<?php $this->options->charset(); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	
    <title><?php if($this->is('index')){ ?><?php $this->options->title(); ?> - <?php $this->options->subtitle(); ?><?php if($this->_currentPage>1) echo ' - '.$this->_currentPage.' page '; ?><?php }  else { ?><?php $this->archiveTitle('', '', ''); ?> - <?php $this->options->title(); ?><?php } ?></title>
    
	<link rel="stylesheet" href="<?php $this->options->themeUrl('css/style.css'); ?>">	
	<script>window._deel = {name: 'TypeD8主题',url: '<?php $this->options->themeUrl(); ?>',commenton: 0,roll: [1,],appkey: {tqq: '801494063',tsina: '1106777879',t163: '',tsohu: ''}}</script>
	<?php $this->header('generator=&template=&pingback=&xmlrpc=&wlw='); ?>
</head>

<body class="home blog">
	<div class="navbar-wrap">
		<div class="navbar">
			<h1 class="logo"><a href="<?php $this->options->siteUrl(); ?>" title="<?php $this->options->title() ?>"><?php $this->options->title() ?></a></h1>
			<ul class="nav active" style="display">
				<li><a href="<?php $this->options->siteUrl(); ?>">Home</a></li>
				<?php $this->widget('Widget_Metas_Category_List')
			   ->parse('<li class="menu-item"><a href="{permalink}">{name}</a></li>'); ?>
				<li><a>独立页面</a>
				
					<ul class="sub-menu">
					<?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>						
                    <?php while($pages->next()): ?>
					<li class="menu-item"><a href="<?php $pages->permalink(); ?>"title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a></li>
                    <?php endwhile; ?>
					</ul>
				</li>
			</ul>
			
			<div class="screen-mini">
				<button data-type="screen-nav" class="btn btn-inverse screen-nav"><i class="icon-tasks icon-white"></i></button>
			</div>
			
			<div class="menu pull-right">
				<form method="get" class="dropdown search-form" action="<?php $this->options->siteUrl(); ?>" >
				<input class="search-input" name="s" type="text" placeholder="input your keyword" x-webkit-speech="">
				<input class="btn btn-success search-submit" type="submit" value="Search">
				</form>
				
				<div class="btn-group pull-left">
					<a class="btn btn-primary" target="_blank" href="<?php $this->options->siteUrl(); ?>feed/">Feed</a>
					<button class="btn btn-primary dropdown-toggle" data-toggle="dropdown">Links <i class="caret"></i></button>
					<ul class="dropdown-menu pull-right">
						<?php $this->options->ulinks(); ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
	
	<header class="header">
		<div class="speedbar">
			<div class="toptip"><strong class="text-success">News：</strong><?php $this->options->tips(); ?></div>
		</div>
	</header>
<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<section class="container">

	<div class="content-wrap">
	<div class="content">
	<div class="sticky">
	
</div>
<section class="container">
	<h2 class="title"> <?php $this->archiveTitle(array(
            'category'  =>  _t('%s'),
        ), '', ''); ?></h2>
<?php while($this->next()): ?>

<article class="excerpt excerpt-titletype">
		<div class="focus"><a href="<?php $this->permalink() ?>" class="thumbnail"><?php if ($this->options->RandomPicChoice !=='0' && array_key_exists('thumb',unserialize($this->___fields()))): ?>
	    <img src="<?php echo $this->fields->thumb; ?>"></img>
	    <?php else: ?>
          <?php $thumb = showThumbnail($this); if(!empty($thumb)): ?>
	 <img src="<?php echo $thumb ?>"></img>
	   <?php endif; ?>
        <?php endif; ?></a></div>
		<header>
				<h2><a href="<?php $this->permalink() ?>" title="<?php $this->title() ?>"><?php $this->title() ?></a></h2>
	</header>
	<p><span class="muted muted_author"><i class="icon-user icon12"></i> <?php $this->author(); ?></span>
				<time class="muted" datetime="<?php $this->date('c'); ?>" title="<?php $this->date('y/m/d'); ?>"><i class="ico icon-time icon12"></i> <?php $this->date('Y/m/d'); ?></time>
				<span class="muted"><i class="icon-eye-open icon12"></i> <?php get_post_view($this) ?></span>
				<span class="muted"><i class="icon-comment icon12"></i> <a href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum(); ?> 条</a></span></p>	<p class="note">
		<?php $this->excerpt(50, '...'); ?>  </p>
</article>
<?php endwhile; ?>
</article>
<div class="pagination">
<ul>
<li class="prev-page"></li>
<a href='<?php $this->options->siteUrl(); ?>'>首页</a>
                    <?php $this->pageLink('<x aria-label="Previous" class="newer-posts"><i class="fa fa-angle-left"></i></x>'); ?>
    <span class="page-number">第 <?php if($this->_currentPage>1) echo $this->_currentPage;  else echo 1;?> 页 / 共 <?php echo ceil($this->getTotal() / $this->parameter->pageSize); ?> 页</span>
        <?php $this->pageLink('<x aria-label="Next" class="older-posts">下一页<i class="fa fa-angle-right"></i></x>','next'); ?></ul></div>	</div>
</div>
<?php $this->need('sidebar.php'); ?>

<?php $this->need('footer.php'); ?>
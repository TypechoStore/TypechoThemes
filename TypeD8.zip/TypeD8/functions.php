<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
// 设置时区
date_default_timezone_set('Asia/Shanghai');

function themeInit($archive)
{
    Helper::options()->commentsMaxNestingLevels = 999;
}

function themeConfig($form) {
	// 顶部通知
	$subtitle = new Typecho_Widget_Helper_Form_Element_Text('subtitle', NULL, _t('这是一个新的Typecho主题'), _t('网站副标题'), _t('显示在网页标题里的副标题'));
    $form->addInput($subtitle);
	
	$tips = new Typecho_Widget_Helper_Form_Element_Textarea('tips', NULL, _t('这是一个新的Typecho主题，如果使用问题请反馈给我QQ1989473781'), _t('顶部通知'), _t('顶部通知，支持HTML'));
    $form->addInput($tips);
	
	$ulinks = new Typecho_Widget_Helper_Form_Element_Textarea('ulinks', NULL, _t('<li><a href="https://www.nihaowua.com" target="_blank">你好污啊</a></li>
<li><a href="https://www.1024lua.com" target="_blank">韩粉乐园</a></li>
<li><a href="https://www.typecho.wiki" target="_blank">TypechoWiki</a></li>'), _t('顶部友链'), _t('顶部标题栏的友链'));
    $form->addInput($ulinks);
	
	$hot = new Typecho_Widget_Helper_Form_Element_Text('hot', NULL, _t('1,1'), _t('置顶文章'), _t('请输入要置顶展示文章的cid，只能两个并用英文逗号分开'));
    $form->addInput($hot);
	
	//$tuijian2 = new Typecho_Widget_Helper_Form_Element_Text('tj_cid2', NULL, NULL, _t('置顶文章B'), _t('请输入要置顶展示文章的cid'));
    //$form->addInput($tuijian2);
	
	//幻灯片
	$Slider = new Typecho_Widget_Helper_Form_Element_Radio('Slider',
        array('SliderTrue'=>_t('开启'),'SliderFalse'=>_t('关闭')),
        'SliderFalse',
        _t("幻灯片开关"),
        _t("开启后请在下方填写来幻灯片代码发布幻灯片")
        );
    $form->addInput($Slider); 

	$slidercode = new Typecho_Widget_Helper_Form_Element_Textarea('slidercode', NULL, _t('<a href="https://www.moidea.info"><img src="http://demo.themebetter.com/xiu/wp-content/uploads/sites/2/2015/06/116.jpg"></a>
<a href="https://www.moidea.info"><img src="http://demo.themebetter.com/xiu/wp-content/uploads/sites/2/2015/06/ui-02.jpg"></a>'), _t('幻灯片代码'), _t('请按此格式填写，展示几个就填几行&lt;a href="你的链接"&gt; &lt;img src="图片链接" width="100%" /&gt;&lt;/a&gt;'));
	$form->addInput($slidercode);
	

	$buildTime = new Typecho_Widget_Helper_Form_Element_Text('buildTime', NULL, _t('2015-04-18 00:00:00'), _t('建站时间'), _t('请按照格式填写：2015-04-18 00:00:00'));
    $form->addInput($buildTime);
	
    
	// 文章缩略图数目设置
    $RandomPicAmnt = new Typecho_Widget_Helper_Form_Element_Text('RandomPicAmnt', NULL, _t('5'), _t('首页文章随机缩略图数量设置'), _t('对应于主题目录下的img/sj 文件夹中的图片的数量。说明：文章头图显示方式：<b>thumb（自定义字段）--> 文章第一张图片 --> 随机图片输出</b>。图片必须以从1开始的数字命名，而且必须是.jpg文件'));
    $form->addInput($RandomPicAmnt);

	//文章缩略图设置
   $RandomPicChoice = new Typecho_Widget_Helper_Form_Element_Radio('RandomPicChoice',
        array(
            '0' => _t('只显示随机图片'),
            '1' => _t('显示顺序：thumb自定义字段——文章第一张图片'),
            '2' => _t('显示顺序：thumb自定义字段——文章第一张图片——随机图片(推荐)')
        ),
    
	//Default choose
        '5',_t('首页文章缩略图设置'),_t('该功能对首页文章缩略图生效。推荐选择第三个。<br><span style="color: #f00">注意</span>：此项设置仅在全局设置开启头图后才生效')
    );
    $form->addInput($RandomPicChoice);
	
	//幻灯片
	$tuijian = new Typecho_Widget_Helper_Form_Element_Radio('tuijian',
        array('tuijianTrue'=>_t('开启'),'tuijianFalse'=>_t('关闭')),
        'tuijianFalse',
        _t("侧栏推荐广告开关"),
        _t("开启后请在下方填写来侧边栏推荐位代码")
        );
    $form->addInput($tuijian); 
	
	$sidebarAD = new Typecho_Widget_Helper_Form_Element_Textarea('sidebarAD', NULL, NULL, _t('侧边栏推荐位'), _t('请按固定格式填写，否则会造成错乱，可添加多个，第一行是广告的链接地址，第二行是广告标题，第三行是广告内容<br>例如:<br>https://www.moidea.info<br>TypeD8主题 新一代主题<br>TypeD8 Typecho主题是一款基于大前端D8主题移植的主题，是大前端积累多年Wordpress主题经验设计而成；更加扁平的风格和干净白色的架构会让网站显得内涵而出色...'));
    $form->addInput($sidebarAD);
}


// 首页文章缩略图

function showThumbnail($widget)
{ 
    // 当文章无图片时的默认缩略图
    $rand = rand(1,$widget->widget('Widget_Options')->RandomPicAmnt); // 随机 1-3 张缩略图

    $random = $widget->widget('Widget_Options')->themeUrl . '/images/sj/' . $rand . '.jpg'; // 随机缩略图路径
    //正则匹配 主题目录下的/images/sj/的图片（以数字按顺序命名）

$cai = '';
if (!empty($attachments)){
    $attach = $widget->attachments(1)->attachment;
}
else{
    $attach='';
}
    $pattern = '/\<img.*?src\=\"(.*?)\"[^>]*>/i'; 
  $patternMD = '/\!\[.*?\]\((http(s)?:\/\/.*?(jpg|png))/i';
    $patternMDfoot = '/\[.*?\]:\s*(http(s)?:\/\/.*?(jpg|png))/i';

//调用第一个图片附件
if ($attach && $attach->isImage) {
    $ctu = $attach->url.$cai;
} 

//下面是调用文章第一个图片
else if (preg_match_all($pattern, $widget->content, $thumbUrl)) {
    $ctu = $thumbUrl[1][0].$cai;
}

//如果是内联式markdown格式的图片
else if (preg_match_all($patternMD, $widget->content, $thumbUrl)) {
    $ctu = $thumbUrl[1][0].$cai;
}
//如果是脚注式markdown格式的图片
else if (preg_match_all($patternMDfoot, $widget->content, $thumbUrl)) {
    $ctu = $thumbUrl[1][0].$cai;
}
//以上都不符合，即随机输出图片
else {
    if($widget->widget('Widget_Options')->RandomPicChoice =='1')
        $ctu='';
    else
        $ctu = $random;
}
//return输出
if ($widget->widget('Widget_Options')->RandomPicChoice =='0' ){
    return $random;
}
else{
    return $ctu;
}

}

//文章页面侧边栏缩略图
function showThumbnail2($widget)
{ 
    // 当文章无图片时的默认缩略图
    $rand = rand(1,$widget->widget('Widget_Options')->RandomPicAmnt2); // 随机 1-15 张缩略图

    $random = $widget->widget('Widget_Options')->themeUrl . '/img/sj2/' . $rand . '.jpg'; // 随机缩略图路径
    //正则匹配 主题目录下的/images/sj/的图片（以数字按顺序命名）

return $random;
}

/**
* 显示上一篇
*
* @access public
* @param string $default 如果没有上一篇,显示的默认文字
* @return void
*/
function theNext($widget, $default = NULL)
{
$db = Typecho_Db::get();
$sql = $db->select()->from('table.contents')
->where('table.contents.created > ?', $widget->created)
->where('table.contents.status = ?', 'publish')
->where('table.contents.type = ?', $widget->type)
->where('table.contents.password IS NULL')
->order('table.contents.created', Typecho_Db::SORT_ASC)
->limit(1);
$content = $db->fetchRow($sql);

if ($content) {
$content = $widget->filter($content);
$link = '<a href="' . $content['permalink'] . '" title="' . $content['title'] . '" data-toggle="tooltip"> 上一篇 </a>

';
echo $link;
} else {
$link = '';
echo $link;
}
}
 
/**
* 显示下一篇
*
* @access public
* @param string $default 如果没有下一篇,显示的默认文字
* @return void
*/
function thePrev($widget, $default = NULL)
{
$db = Typecho_Db::get();
$sql = $db->select()->from('table.contents')
->where('table.contents.created < ?', $widget->created)
->where('table.contents.status = ?', 'publish')
->where('table.contents.type = ?', $widget->type)
->where('table.contents.password IS NULL')
->order('table.contents.created', Typecho_Db::SORT_DESC)
->limit(1);
$content = $db->fetchRow($sql);
 
if ($content) {
$content = $widget->filter($content);
$link = '<a href="' . $content['permalink'] . '" title="' . $content['title'] . '" data-toggle="tooltip"> 下一篇 </a>';
echo $link;
} else {
$link = '';
echo $link;
}
}

//随机显示文章
function theme_random_posts($random){
$defaults = array(
'number' => 5, //输出文章条数
'xformat' => '<li><a href="{permalink}">{title}</a></li>'
);
$db = Typecho_Db::get();
 
$sql = $db->select()->from('table.contents')
->where('status = ?','publish')
->where('type = ?', 'post')
->limit($defaults['number'])
->order('RAND()');
 
$result = $db->fetchAll($sql);
foreach($result as $val){
$val = Typecho_Widget::widget('Widget_Abstract_Contents')->filter($val);
echo '<li class="list-group-item">
                <a href="' . $val['permalink'] . '" class="pull-left thumb-sm m-r">
                <img style="height: 40px!important;width: 40px!important;" src="'.showThumbnail2($random).'" class="img-circle wp-post-image">
                </a>
                <div class="clear">
                    <h4 class="h5 l-h"> <a href="' . $val['permalink'] . '" title="' . $val['title'] . '"> ' . $val['title'] . ' </a></h4>
                    <small class="text-muted">
                    <span class="meta-views"> <i class="iconfont icon-comments" aria-hidden="true"></i> <span class="sr-only">评论数：</span> <span class="meta-value">'.$val['commentsNum'].'</span> 
                    </span>  
                    <span class="meta-date m-l-sm"> <i class="iconfont icon-eye" aria-hidden="true"></i> <span class="sr-only">浏览次数:</span> <span class="meta-value">'.$val['views'].'</span> 
                    </span> 
                    </small>
                    </div>
            </li>';
}
}



/**
* 秒转时间，格式 年 月 日 时 分 秒
*
* @author Roogle
* @return html
*/
function getBuildTime(){
// 在下面按格式输入本站创建的时间
$options = Typecho_Widget::widget('Widget_Options');
if (!empty($options->buildTime)) {
    $site_create_time = strtotime($options->buildTime);
    //echo $site_create_time;
}else{
    $site_create_time = strtotime('2015-04-18 00:00:00');
    //echo $site_create_time;
}
$time = time() - $site_create_time;
if(is_numeric($time)){
$value = array(
"years" => 0, "days" => 0, "hours" => 0,
"minutes" => 0, "seconds" => 0,
);
if($time >= 31556926){
$value["years"] = floor($time/31556926);
$time = ($time%31556926);
}
if($time >= 86400){
$value["days"] = floor($time/86400);
$time = ($time%86400);
}
if($time >= 3600){
$value["hours"] = floor($time/3600);
$time = ($time%3600);
}
if($time >= 60){
$value["minutes"] = floor($time/60);
$time = ($time%60);
}
$value["seconds"] = floor($time);
 
echo ''.$value['years'].'年'.$value['days'].'天';
}else{
echo '';
}
}





//侧边栏推荐位
function sitebar_ad($obj) {
    $options = $obj;
    if (!empty($options)) {
        $text = $options;
    }else{
		$text="https://www.moidea.info\nTypeD8主题 新一代主题\nTypeD8 Typecho主题是一款基于大前端D8主题移植的主题，是大前端积累多年Wordpress主题经验设计而成；更加扁平的风格和干净白色的架构会让网站显得内涵而出色...";
	}
	$b_arr = explode("\n", $text);
		
	return $b_arr;
}


// 首页置顶
function hotpost() {
    $options = Typecho_Widget::widget('Widget_Options');
    if ((!empty($options->hot)) && floor($options->hot)==$options->hot) {
        $tjids =  $options->hot;
    }
	$hot_arr = explode(",", $tjids);
	if(count($hot_arr) < 2){
		$hot_arr[] = 1;
	}
	
	//if ((!empty($options->tj_cid2)) && floor($options->tj_cid2)==$options->tj_cid2) {
    //    $tjids2 =  $options->tj_cid2;
    //}
	
	$db = Typecho_Db::get();	
	$sticky_posts = $db->fetchAll($db->select()->from('table.contents')
	->orWhere('cid = ?',$hot_arr[0])
	->orWhere('cid = ?', $hot_arr[1])
	->where('type = ? AND status = ? AND password IS NULL', 'post', 'publish'));	
	
	rsort( $sticky_posts );//对数组逆向排序，即大ID在前 
	foreach ($sticky_posts as $sticky_posts) {
		$result = Typecho_Widget::widget('Widget_Abstract_Contents')->push($sticky_posts);
		
		$post_title = htmlspecialchars($result['title']);		
		$permalink = $result['permalink'];
		//$post_date = date('M d,Y', $result['created']);
		//$post_views = number_format($result['views']);
		/*if($post_views > $this->options->view_num){echo 'HOT';} else {echo ''.$post_views.''' VIEW';};*/	
			
		preg_match_all( "/\[.*?\]:\s*(http(s)?:\/\/.*?(jpg|png|gif))/i", $result['text'], $matches );
		if(isset($matches[1][0])){
			$thumb = $matches[1][0];
		}else{
			$thumb= $options->themeUrl .'/images/sj/' . rand(1, 5) . '.jpg';
		}
		echo '<li class="item"><a href="'.$permalink.'"><img src="'.$thumb.'" alt="'.$post_title.'"><h3>'.$post_title.'</h3><p class="muted">'.myGBsubstr($result['text'],0,120).'</p></a></li>';}
}

// 字符串截取
function myGBsubstr($string, $start, $length) {
    if (strlen($string) > $length) {
        $str = null;
        $len = 0;
        $i = $start;
        while ( $len < $length) {
        if (ord(substr($string, $i, 1)) > 0xc0) {
            $str .=substr($string, $i, 3);
            $i+= 3;
        }elseif (ord(substr($string, $i, 1)) > 0xa0) {
            $str .= substr($string, $i, 2);
            $i+= 2;
        }else {
            $str.=substr($string, $i, 1);
            $i++;
        }
        $len ++;
        }
        return $str;
    }else {
        return $string;
    }
}



// 随机文章
function getRandomPosts($limit = 10){    
    $db = Typecho_Db::get();
    $result = $db->fetchAll($db->select()->from('table.contents')
		->where('status = ?','publish')
		->where('type = ?', 'post')
		->where('created <= unix_timestamp(now())', 'post')
		->limit($limit)
		->order('RAND()')
	);
	if($result){
		$i=1;
		foreach($result as $val){
			if($i<=3){
				$var = ' class="red"';
			}else{
				$var = '';
			}
			$val = Typecho_Widget::widget('Widget_Abstract_Contents')->push($val);
			$post_title = htmlspecialchars($val['title']);
			$permalink = $val['permalink'];
			echo '<li><i'.$var.'>'.$i.'</i><a href="'.$permalink.'" title="'.$post_title.'" target="_blank">'.$post_title.'</a></li>';
			$i++;
		}
	}
}


// 浏览量统计
function get_post_view($archive)
{
    $cid    = $archive->cid;
    $db     = Typecho_Db::get();
    $prefix = $db->getPrefix();
    if (!array_key_exists('views', $db->fetchRow($db->select()->from('table.contents')))) {
        $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `views` INT(10) DEFAULT 0;');
        echo 0;
        return;
    }
    $row = $db->fetchRow($db->select('views')->from('table.contents')->where('cid = ?', $cid));
    if ($archive->is('single')) {
 $views = Typecho_Cookie::get('extend_contents_views');
        if(empty($views)){
            $views = array();
        }else{
            $views = explode(',', $views);
        }
if(!in_array($cid,$views)){
       $db->query($db->update('table.contents')->rows(array('views' => (int) $row['views'] + 1))->where('cid = ?', $cid));
array_push($views, $cid);
            $views = implode(',', $views);
            Typecho_Cookie::set('extend_contents_views', $views); //记录查看cookie
        }
    }
    echo $row['views'].'';
}


//幻灯片输出
function slout() {
    $options = Typecho_Widget::widget('Widget_Options');
    if (!empty($options->slidercode)) {
        $text = $options->slidercode;
    }else{
		$text='<a href="https://www.moidea.info"><img src="http://demo.themebetter.com/xiu/wp-content/uploads/sites/2/2015/06/116.jpg"></a>
<a href="https://www.moidea.info"><img src="http://demo.themebetter.com/xiu/wp-content/uploads/sites/2/2015/06/ui-02.jpg"></a>';
	}
	$t_arr = explode('
', $text);
	$sss = '<div class="slider-wrap"><ul class="slider-roll">';
	foreach($t_arr as $key=>$val) {
		$sss .= '<li class="item">'.$val.'</li>';
	}
	$sss .= '</ul></div><ol class="slider-ctrl">';
	foreach($t_arr as $key=>$val) {
		$sss .= '<li>'.$key.'</li>';
	}
	
	$sss .= '</ol>';
	
	echo $sss;
}